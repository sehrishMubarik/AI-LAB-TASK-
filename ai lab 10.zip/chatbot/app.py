from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/get_response', methods=['POST'])
def get_response():
    user_input = request.json['message'].lower()

    # Simple rule-based responses
    if "hello" in user_input or "hi" in user_input:
        response = "Hello! Welcome to ABC University Admission Chatbot. What’s your name?"
    elif "name is" in user_input:
        name = user_input.split("name is")[-1].strip().capitalize()
        response = f"Nice to meet you, {name}! What program are you applying for? (BS, MS, PhD)"
    elif "bs" in user_input or "ms" in user_input or "phd" in user_input:
        response = "Great! Which department are you interested in? (e.g., CS, BBA, EE)"
    elif "cs" in user_input or "bba" in user_input or "ee" in user_input:
        response = "Please provide your previous qualification and GPA/Percentage."
    elif "intermediate" in user_input or "bachelor" in user_input:
        response = "Thank you. Based on your input, you're eligible to apply. Please visit our official admission portal for further steps."
    else:
        response = "Sorry, I didn’t understand that. Can you please rephrase?"

    return jsonify({'response': response})

if __name__ == '__main__':
    app.run(debug=True)
