from flask import Flask, render_template, request, url_for, redirect, flash
from models.load_model import predict_sentiment

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    # Get and sanitize input
    headline = request.form.get('headline', '').strip()
    description = request.form.get('description', '').strip()

    # Validate inputs
    if not headline or not description:
        flash("Both headline and description are required.", "danger")
        return redirect(url_for('index'))

    try:
        # Predict sentiment using your model
        sentiment = predict_sentiment(headline, description)

        # Show results
        return render_template(
            'result.html',
            headline=headline,
            description=description,
            sentiment=sentiment
        )
    except Exception as e:
        # Handle any model or server errors
        flash(f"An error occurred while processing: {e}", "danger")
        return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
